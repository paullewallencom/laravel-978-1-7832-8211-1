# Recipe Work


## Setup

bower install and npm install to start

[![Build Status](https://travis-ci.org/alnutile/recipes.svg?branch=master)](https://travis-ci.org/alnutile/recipes)

## Running Behat

You will see the suites in the file.

You can run them as such

~~~
vendor/bin/behat -shome_ui
~~~

home_ui being a suite

If you add to that " --append-snippets" it will build out the Feature for you

