@if(isset($title))
    <div class="masthead">
        <div class="container">
            <div class="masthead-subtitle">
                {{ $title }}
            </div>
        </div>
    </div>
@endif