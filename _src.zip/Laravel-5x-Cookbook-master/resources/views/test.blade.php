<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body class="">
<div>

    You are here...

    <div id="here"></div>

    <script src="/js/jquery-1.12.3.js"></script>
    <script src="/js/examplecors.js"></script>
</div>
</body>
</html>