<div class="pricing-tables">

    <div class="row">
        <div class="col-sm-4 col-md-4">
            @include('stripe.level2')
        </div>


        <div class="col-sm-4 col-md-4 ">
            @include('stripe.level1')
        </div>


        <div class="col-sm-4 col-md-4  ">
            @include('stripe.fan')

        </div>

    </div> <!-- row-->

</div> <!-- pricing-tables -->