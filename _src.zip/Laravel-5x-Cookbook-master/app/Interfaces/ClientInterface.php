<?php

namespace App\Interfaces;

interface ClientInterface
{
}
