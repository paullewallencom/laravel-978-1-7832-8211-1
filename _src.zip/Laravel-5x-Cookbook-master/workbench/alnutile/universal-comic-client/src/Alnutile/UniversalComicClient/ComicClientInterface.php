<?php


namespace Alnutile\UniversalComicClient;

interface ComicClientInterface
{

    public function comics($title = false);
}
