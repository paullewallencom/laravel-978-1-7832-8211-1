# Universal Comic Client

## Install

### ENV Settings

~~~
MARVEL_API_KEY=bar
MARVEL_API_SECRET=foo
~~~

## Roadmap

Tons to do