#!/bin/sh
cd ~/app
php artisan migrate --force
